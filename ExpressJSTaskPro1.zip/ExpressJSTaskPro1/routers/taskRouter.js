const express=require("express")
const{getAllTasks,createTask,getTask,updateTask,deleteTask}=require("../controllers/taskController")

//router instances
let taskRouter=express.Router()
taskRouter.get("/",getAllTasks)

taskRouter.post("/",createTask)

taskRouter.get("/:taskID",getTask)

taskRouter.put("/:taskID",updateTask)

taskRouter.delete("/:taskID",deleteTask)

module.exports=taskRouter;