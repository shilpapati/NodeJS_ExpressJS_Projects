const express=require("express")
const mongoose=require('mongoose')
const cors =require("cors")
const MONGODB_URI='mongodb://127.0.0.1:27017/task-expressDB'
const taskRouter=require("./routers/taskRouter")
const methodOverride=require("method-override")
//APP INSTANCE
let app=express()


//REGISTER THE TEMPLATE
app.set('view engine','ejs')

//DB CONNECTION
mongoose.connect(MONGODB_URI).then(()=>{
    console.log("db connected");

}).catch((err)=>{
    console.log(err);
})

//root route
app.use(cors())

app.use(express.json()) 
app.use(express.urlencoded({extended:true}))
//methodOverride to update method, as method supports only get and post
app.use(methodOverride('_method'))

app.use(express.static('public'))
app.use("/app/v1/tasks",taskRouter)

module.exports=app