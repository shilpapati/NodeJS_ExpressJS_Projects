const {Schema,model}=require('mongoose')

//Structure
const taskSchema=new Schema({
    task:{
        type:String,
        required:[true,"task is required"],
        trime:true
    }
},
{
    timestamps:true
})
const Task=model("task",taskSchema)
module.exports=Task