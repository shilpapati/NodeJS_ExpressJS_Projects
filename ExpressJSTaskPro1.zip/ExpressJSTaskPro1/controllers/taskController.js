const Task =require("../models/Task")

const getAllTasks=async(req,res)=>{
    try{
        let tasks=await Task.find()
        res.status(200).render('home',{tasks:tasks})
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}

const createTask=async(req,res)=>{
    try{
        await Task.create(req.body)
        res.status(201).redirect('/app/v1/tasks')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}

const getTask=async(req,res)=>{
    try{
        let id=req.params.taskID
        let task=await Task.findById(id)
        res.status(200).render("update",{task:task})
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}


const updateTask=async(req,res)=>{
    try{
        let id=req.params.taskID
        await Task.findByIdAndUpdate(id,req.body,{new:true,runValidators:true})
        res.status(200).redirect('/app/v1/tasks')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}

const deleteTask=async(req,res)=>{
    try{
        let id=req.params.taskID
        await Task.findByIdAndDelete(id)
        res.status(200).redirect('/app/v1/tasks')
    }catch(err){
        res.status(400).json({
            status:"fail",
            message:err.message
        })
    }
}
module.exports={
    getAllTasks, createTask, getTask, updateTask, deleteTask
}