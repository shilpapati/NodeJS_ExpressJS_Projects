const http = require("http")
const app=require("./app")
let server = http.createServer(app)
server.listen(5000, (err) => {
    if (err)
        console.log(err);
    else
        console.log("server running in the port 5000");

})